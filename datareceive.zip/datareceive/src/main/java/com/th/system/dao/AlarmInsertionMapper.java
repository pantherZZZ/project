package com.th.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.th.system.po.SysAlarmInsertion;

/**
 * @Author zhang bao
 * @Date 2022/1/10 23:02
 * @Version 1.0
 */
public interface AlarmInsertionMapper extends BaseMapper<SysAlarmInsertion> {
}
