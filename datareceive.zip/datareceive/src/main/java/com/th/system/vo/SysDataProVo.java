package com.th.system.vo;

public class SysDataProVo {

	private String DTUCount;
	
	private String FullRate;
	
	private String SensorCount;
	
	private String ValidRate;

	public String getDTUCount() {
		return DTUCount;
	}

	public void setDTUCount(String dTUCount) {
		DTUCount = dTUCount;
	}

	public String getFullRate() {
		return FullRate;
	}

	public void setFullRate(String fullRate) {
		FullRate = fullRate;
	}

	public String getSensorCount() {
		return SensorCount;
	}

	public void setSensorCount(String sensorCount) {
		SensorCount = sensorCount;
	}

	public String getValidRate() {
		return ValidRate;
	}

	public void setValidRate(String validRate) {
		ValidRate = validRate;
	}
	
	
}
