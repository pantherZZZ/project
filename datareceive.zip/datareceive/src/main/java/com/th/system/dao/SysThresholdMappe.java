package com.th.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.th.system.po.Threshold;

/**
 * @Author zhang bao
 * @Date 2022/1/10 21:29
 * @Version 1.0
 */
public interface SysThresholdMappe extends BaseMapper<Threshold> {

}
