package com.th.system.service;

import com.th.system.po.SysProject;

/**
 * @Author zhang bao
 * @Date 2022/1/12 10:31
 * @Version 1.0
 */
public interface ProjectService {
    SysProject selectProject(int projectId);
}
