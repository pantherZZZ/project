package com.th.system.dao;

import com.th.system.po.SysModelAndDetectionFacility;

public interface SysModelAndDetectionFacilityMapper {
	
	//新增
	public Integer insert(SysModelAndDetectionFacility sysModelAndDetectionFacility);
}
