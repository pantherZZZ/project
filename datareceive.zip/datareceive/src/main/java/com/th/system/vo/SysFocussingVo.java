package com.th.system.vo;

import com.th.system.po.SysFocussing;

public class SysFocussingVo extends SysFocussing{

	private String factorName;

	public String getFactorName() {
		return factorName;
	}

	public void setFactorName(String factorName) {
		this.factorName = factorName;
	}
	
}
