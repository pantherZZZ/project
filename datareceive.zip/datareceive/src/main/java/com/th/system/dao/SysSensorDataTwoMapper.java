package com.th.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.th.system.po.SensorDataTwo;

/**
 * @Author zhang bao
 * @Date 2022/1/11 15:52
 * @Version 1.0
 */
public interface SysSensorDataTwoMapper extends BaseMapper<SensorDataTwo> {
}
