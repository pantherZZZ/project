package com.th.system.po;
//sys_projecAndModel
public class SysProjecAndModel {
	
	private int projectId;//project表Id
	
	private int modelId;//model表id

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}
	
}
