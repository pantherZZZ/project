package com.th.system.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.th.system.po.SysMeasure;

/**
 * @Author zhang bao
 * @Date 2022/1/5 17:43
 * @Version 1.0
 */
public interface SysMeasuringPointMapper extends BaseMapper<SysMeasure> {
}
