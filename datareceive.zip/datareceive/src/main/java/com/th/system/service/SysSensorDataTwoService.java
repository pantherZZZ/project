package com.th.system.service;

/**
 * 对接数据总条数
 * @Author zhang bao
 * @Date 2022/1/11 15:49
 * @Version 1.0
 */
public interface SysSensorDataTwoService {
    Long selectSensorDataTwo();
}
