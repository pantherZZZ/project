package com.th.system.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.th.system.po.SysModelAndDetectionFacility;

public interface SysModelAndDetectionFacilityService {

	//新增
	public Integer insert(SysModelAndDetectionFacility sysModelAndDetectionFacility);
	
}
