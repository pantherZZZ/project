package com.th.system.controller;

//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/auth")
public class AuthController {

//	@PostMapping("/superuser")
//	public ResponseEntity superuser(String clientid,String username) {
//		return null;
//	}
//	@PostMapping("/acl")
//	public ResponseEntity acl(@RequestParam("access")int access,
//							  @RequestParam("username")String username,
//							  @RequestParam("clientid")String clientid,
//							  @RequestParam("ipadde")String ipadde,
//							  @RequestParam("topic") String topic,
//							  @RequestParam("mountpoint")String mountpoint) {
//		return new ResponseEntity(HttpStatus.OK);
//	}
//	
}
